const mongoose = require("mongoose");
const DB = 'mongodb+srv://lcb2021014:palash@cluster0.3nibuvg.mongodb.net/test'
mongoose.connect(DB).then(()=>{
    console.log("connection successful");
}).catch((err)=>console.error(err));

