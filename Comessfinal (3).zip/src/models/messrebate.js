const mongoose = require("mongoose");

const messrebSchema = new mongoose.Schema({
datesubmission:{
    type:String,
    required : true
},
name:{
  type:String,
  required: true
},
rollno:{
    type: String,
    required :true
},
from:{
    type: String,
    required: true
},
to:{
    type: String,
    required:true
},
days:{
    type:Number,
    required:true
}

});


const Messreb = new mongoose.model("messreb",messrebSchema);

module.exports = Messreb;